public class Xcptn extends Exception {

        public Xcptn(String msg)
        {
            super(msg);
        }


}
